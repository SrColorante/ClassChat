<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Invia messaggio
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);
    if (!empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO messages (user_id, message) VALUES (?, ?)");
        $stmt->execute([$_SESSION['user_id'], $message]);
    }
}

// Ottieni messaggi
$stmt = $pdo->prepare("
    SELECT m.message, m.created_at, u.username 
    FROM messages m 
    JOIN users u ON m.user_id = u.id 
    ORDER BY m.created_at DESC 
    LIMIT 50
");
$stmt->execute();
$messages = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Chat Locale</title>
    <link rel="stylesheet" href="css/chat.css">
</head>
<body>
    <div class="header">
        <h1>Chat Locale</h1>
        <div>
            <span>Benvenuto, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <a href="logout.php" class="logout-button">Logout</a>
        </div>
    </div>

    <div class="container">
        <div class="chat-messages" id="chat-messages">
            <?php foreach ($messages as $msg): ?>
                <div class="message">
                    <span class="username"><?php echo htmlspecialchars($msg['username']); ?>:</span>
                    <span><?php echo htmlspecialchars($msg['message']); ?></span>
                    <span class="time">(<?php echo $msg['created_at']; ?>)</span>
                </div>
            <?php endforeach; ?>
        </div>

        <form method="POST" class="message-form" id="message-form">
            <input type="text" name="message" class="message-input" placeholder="Scrivi un messaggio..." required>
            <button type="submit" class="send-button">Invia</button>
        </form>
    </div>

    <script>
        // Aggiorna la chat ogni 3 secondi
        setInterval(function() {
            fetch('get_messages.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('chat-messages').innerHTML = data;
                    // Scroll automatico verso il basso
                    const chatMessages = document.getElementById('chat-messages');
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                });
        }, 3000);

        // Scroll automatico all'inizio
        window.onload = function() {
            const chatMessages = document.getElementById('chat-messages');
            chatMessages.scrollTop = chatMessages.scrollHeight;
        };
    </script>
</body>
</html>
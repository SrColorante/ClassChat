# ClassChat
local hosted chat for LAN IT labs.

1. Start Apache & MySQL servers.
2. Copy all .php files in htdocs.
3. go to localhost/phpmyadmin.
4. create a "chat_db" database.
5. copy the chat_db.sql code in the SQL section.

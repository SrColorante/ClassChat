<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Imposta ordinamento di default nella sessione se non presente
if (!isset($_SESSION['message_order'])) {
    $_SESSION['message_order'] = 'asc';
}

// Cambia ordinamento se richiesto
if (isset($_GET['change_order'])) {
    $_SESSION['message_order'] = $_SESSION['message_order'] === 'asc' ? 'desc' : 'asc';
    header('Location: chat.php');
    exit;
}

// Invia messaggio
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $message = trim($_POST['message']);
    if (!empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO messages (user_id, message) VALUES (?, ?)");
        $stmt->execute([$_SESSION['user_id'], $message]);
    }
}

// CORREZIONE: usa ORDER BY invece di ORDINE BY
$order = $_SESSION['message_order'];
$stmt = $pdo->prepare("
    SELECT m.message, m.created_at, u.username, m.user_id
    FROM messages m 
    JOIN users u ON m.user_id = u.id 
    ORDER BY m.created_at $order
    LIMIT 50
");
$stmt->execute();
$messages = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Chat Locale</title>
    <link rel="stylesheet" href="css/chat.css">
</head>
<body>
    <div class="header">
        <h1>Chat Locale</h1>
        <div class="header-controls">
            <span>Benvenuto, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <div class="controls">
                <a href="?change_order=1" class="order-button" title="Cambia ordinamento messaggi">
                    <?php echo $_SESSION['message_order'] === 'asc' ? '▼ Più vecchi in alto' : '▲ Più recenti in alto'; ?>
                </a>
                <a href="logout.php" class="logout-button">Logout</a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="chat-messages" id="chat-messages">
            <?php foreach ($messages as $msg): ?>
                <div class="message <?php echo ($msg['user_id'] == $_SESSION['user_id']) ? 'own-message' : ''; ?>">
                    <span class="username"><?php echo htmlspecialchars($msg['username']); ?>:</span>
                    <span><?php echo htmlspecialchars($msg['message']); ?></span>
                    <span class="time">(<?php echo $msg['created_at']; ?>)</span>
                </div>
            <?php endforeach; ?>
        </div>

        <form method="POST" class="message-form" id="message-form">
            <input type="text" name="message" class="message-input" placeholder="Scrivi un messaggio..." required>
            <button type="submit" class="send-button">Invia</button>
        </form>
    </div>

    <script>
        setInterval(function() {
            fetch('get_messages.php?order=<?php echo $_SESSION['message_order']; ?>')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('chat-messages').innerHTML = data;
                    const chatMessages = document.getElementById('chat-messages');
                    if ('<?php echo $_SESSION['message_order']; ?>' === 'desc') {
                        chatMessages.scrollTop = 0;
                    } else {
                        chatMessages.scrollTop = chatMessages.scrollHeight;
                    }
                });
        }, 3000);

        window.onload = function() {
            const chatMessages = document.getElementById('chat-messages');
            if ('<?php echo $_SESSION['message_order']; ?>' === 'desc') {
                chatMessages.scrollTop = 0;
            } else {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            document.querySelector('.message-input').focus();
        };
    </script>
</body>
</html>